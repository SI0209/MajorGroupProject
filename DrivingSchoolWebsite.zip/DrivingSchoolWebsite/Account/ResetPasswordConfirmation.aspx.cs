﻿using System.Web.UI;

namespace DrivingSchoolWebsite.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}