﻿namespace DrivingSchoolBookingSystem
{


    partial class WstGrp2DataSet
    {
        partial class tblEmployeeDataTable
        {
        }
    }
}

namespace DrivingSchoolBookingSystem.WstGrp2DataSetTableAdapters {
    
    
    public partial class tblUnavailableSlotTableAdapter
    {
    }
}
